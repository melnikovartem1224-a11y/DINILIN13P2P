// ====== i18n словари (RU / UA) ======
const I18N = {
  ru: {
    title:"DINIKIN13 — P2P Арбитраж — Премиальный курс", brand:"DINIKIN13", rights:"Все права защищены.",
    nav_about:"О курсе", nav_stats:"Статистика", nav_how:"Как это работает", nav_why:"Почему мы",
    nav_cases:"Кейсы", nav_reviews:"Отзывы", nav_contact:"Контакты", nav_cta:"Связаться", lang_label:"Язык",
    eyebrow:"Арбитраж Р2Р с нуля", h1:"Курс разработан профессиональными арбитражниками",
    lead:"Продуманная структура курса. Полная поддержка в течение всего периода обучения. Команда, инструменты, вопросы — всё в одном месте.",
    tg_cta:"Связаться в Telegram", see_program:"Смотреть программу",
    s_deals_k:"Сделок за 30 дней", s_deals_m:"с использованием мировых бирж",
    s_spread_k:"Средний спред", s_spread_m:"динамика зависит от ситуации на рынке", s_min:"мин.",
    s_reply_k:"Ответы", s_reply_m:"администраторы и поддержка 24/7",
    s_disputes_k:"Споры и проблемы", s_disputes_m:"помогаем решить вопросы с поддержкой и безопасностью",
    about_h2:"О курсе", about_p:"Обучаем всему циклу Р2Р-ордера: от мониторинга цен до закрытия ордера. Пошаговая программа с поддержкой менторов и администраторов.",
    inside_h2:"Что внутри", inside_1_t:"Модульная программа", inside_1_d:"От основ бирж до отчётности и созвонов.",
    inside_2_t:"Живые эфиры", inside_2_d:"Разбор тем, ответы на вопросы, записи трансляций.",
    inside_3_t:"Инструменты", inside_3_d:"Шаблоны расчётов, чек-листы и регламенты.",
    how_h2:"Как это работает", how_p:"Обучаем всему циклу Р2Р ордера: от мониторинга цен до закрытия ордера",
    t1_h:"Основы работы с биржами", t1_d:"Регистрация, верификация, прогрев биржи",
    t2_h:"Аналитика", t2_d:"Обучаем просчитывать прибыль, подбираем интересные курсы",
    t3_h:"Риск-менеджмент", t3_d:"Лимиты по сделкам, правила работы с биржами, подача апелляции и решение спорных ситуаций",
    t4_h:"Администрирование", t4_d:"Администраторы и менторы в чате. Ответы на вопросы, помощь в решении вопросов",
    t5_h:"Отчётность", t5_d:"Помощь и инструменты для прогнозирования прибыли и составление отчётных документов",
    t6_h:"Обучение", t6_d:"Видеоконференции от менторов в прямом эфире. Разбор темы урока. Запись трансляций. Ответы на вопросы от преподавателей курса",
    why_h2:"Почему мы", why_1_t:"Опыт команды", why_1_d:"Курс разработан практикующими арбитражниками.",
    why_2_t:"Поддержка 24/7", why_2_d:"Ответ в среднем до 5 минут.",
    why_3_t:"Низкая доля споров", why_3_d:"Менее 0.5% благодаря регламентам и разбору кейсов.",
    why_4_t:"Прогноз и отчётность", why_4_d:"Даём инструменты для планирования прибыли.",
    pm_h2:"Плюсы и минусы", plus_t:"Плюсы", plus_1:"Быстрый старт с нуля", plus_2:"Готовые регламенты и чек-листы", plus_3:"Сообщество и поддержка", plus_4:"Гибкий формат",
    minus_t:"Минусы", minus_1:"Нужна дисциплина и тайм-менеджмент", minus_2:"Рыночная волатильность влияет на доходность", minus_3:"Требуется верификация на биржах",
    pm_cta:"Написать менеджеру",
    cases_h2:"Успешные кейсы", cases_p:"Реальные результаты учеников по данным их отчётности и переписки с кураторами.",
    case1_badge:"Старт с нуля", case1_h:"Мария, 22 — первые 30 дней", case1_p:"Фокус на 2 биржах, 3 платежные системы, соблюдение лимитов.",
    case2_badge:"Смена стратегии", case2_h:"Игорь, 28 — 60 дней", case2_p:"Перешел с спота на P2P, внедрил шаблоны расчётов и отчётность.",
    case3_badge:"Масштабирование", case3_h:"Оля, 31 — 90 дней", case3_p:"Добавила 2 аккаунта, настроила график и риск-менеджмент.",
    m_deals:"сделок", m_spread:"сред. спред", m_profit:"прибыль",
    reviews_h2:"Отзывы учеников", reviews_p:"Оставьте отзыв — он появится на странице и отправится менеджеру в Telegram.",
    f_name:"Имя", f_rating:"Оценка", f_text:"Ваш отзыв", f_files:"Фото/видео (до 5 файлов)",
    f_hint:"Фото сохраняются в историю отзыва. Видео до ~5 МБ сохраняются, более крупные — видны до перезагрузки. Через ссылку в Telegram файлы не прикрепляются — отправьте их менеджеру отдельно.",
    send_review:"Отправить отзыв", see_reviews:"Смотреть отзывы", consent:"Нажимая «Отправить», вы соглашаетесь с публикацией вашего отзыва на этой странице.",
    contact_h2:"Готов начать?", contact_p:"Задай вопрос или запроси программу на ближайший поток. Менеджер ответит в Telegram.", contact_cta:"Перейти в Telegram",
    faq_1_q:"Нужен ли опыт?", faq_1_a:"Нет, курс рассчитан на старт с нуля, но будет полезен и действующим трейдерам.",
    faq_2_q:"Сколько времени занимает обучение?", faq_2_a:"В среднем 3–6 недель — зависит от вашего темпа и нагрузки.",
    faq_3_q:"Какие биржи?", faq_3_a:"Работаем с крупными международными биржами, акцент на безопасность и регламенты."
  },
  uk: {
    title:"DINIKIN13 — P2P Арбітраж — Преміальний курс", brand:"DINIKIN13", rights:"Усі права захищені.",
    nav_about:"Про курс", nav_stats:"Статистика", nav_how:"Як це працює", nav_why:"Чому ми",
    nav_cases:"Кейси", nav_reviews:"Відгуки", nav_contact:"Контакти", nav_cta:"Звʼязатися", lang_label:"Мова",
    eyebrow:"Арбітраж P2P з нуля", h1:"Курс розроблений професійними арбітражниками",
    lead:"Продумана структура курсу. Повна підтримка протягом усього періоду навчання. Команда, інструменти, запитання — все в одному місці.",
    tg_cta:"Написати в Telegram", see_program:"Дивитися програму",
    s_deals_k:"Угод за 30 днів", s_deals_m:"з використанням світових бірж",
    s_spread_k:"Середній спред", s_spread_m:"динаміка залежить від ринку", s_min:"хв.",
    s_reply_k:"Відповіді", s_reply_m:"адміністратори й підтримка 24/7",
    s_disputes_k:"Спори та проблеми", s_disputes_m:"допомагаємо вирішувати питання з підтримкою та безпекою",
    about_h2:"Про курс", about_p:"Навчаємо всьому циклу P2P-ордера: від моніторингу цін до закриття ордера. Покрокова програма з підтримкою менторів та адміністраторів.",
    inside_h2:"Що всередині", inside_1_t:"Модульна програма", inside_1_d:"Від основ бірж до звітності та колів.",
    inside_2_t:"Живі ефіри", inside_2_d:"Розбір тем, відповіді на запитання, записи трансляцій.",
    inside_3_t:"Інструменти", inside_3_d:"Шаблони розрахунків, чек-листи й регламенти.",
    how_h2:"Як це працює", how_p:"Навчаємо всьому циклу P2P-ордера: від моніторингу цін до закриття",
    t1_h:"Основи роботи з біржами", t1_d:"Реєстрація, верифікація, «прогрів» біржі",
    t2_h:"Аналітика", t2_d:"Вчимо рахувати прибуток, підбираємо вигідні курси",
    t3_h:"Ризик-менеджмент", t3_d:"Ліміти по угодах, правила бірж, апеляції та вирішення спорів",
    t4_h:"Адміністрування", t4_d:"Ментори в чаті. Відповіді та допомога у вирішенні питань",
    t5_h:"Звітність", t5_d:"Інструменти для прогнозу прибутку та підготовки звітних документів",
    t6_h:"Навчання", t6_d:"Відеоконференції наживо. Розбір теми. Записи. Q&A з викладачами",
    why_h2:"Чому ми", why_1_t:"Досвід команди", why_1_d:"Курс створений практикуючими арбітражниками.",
    why_2_t:"Підтримка 24/7", why_2_d:"Відповідь у середньому до 5 хвилин.",
    why_3_t:"Низька частка спорів", why_3_d:"Менше 0.5% завдяки регламентам та розбору кейсів.",
    why_4_t:"Прогноз і звітність", why_4_d:"Даємо інструменти для планування прибутку.",
    pm_h2:"Плюси та мінуси", plus_t:"Переваги", plus_1:"Швидкий старт з нуля", plus_2:"Готові регламенти та чек-листи", plus_3:"Спільнота і підтримка", plus_4:"Гнучкий формат",
    minus_t:"Мінуси", minus_1:"Потрібна дисципліна і тайм-менеджмент", minus_2:"Волатильність ринку впливає на дохідність", minus_3:"Потрібна верифікація на біржах",
    pm_cta:"Написати менеджеру",
    cases_h2:"Успішні кейси", cases_p:"Реальні результати учнів за їхньою звітністю та перепискою з кураторами.",
    case1_badge:"Старт з нуля", case1_h:"Марія, 22 — перші 30 днів", case1_p:"Фокус на 2 біржах, 3 платіжні системи, дотримання лімітів.",
    case2_badge:"Зміна стратегії", case2_h:"Ігор, 28 — 60 днів", case2_p:"Перейшов зі спота на P2P, впровадив шаблони та звітність.",
    case3_badge:"Масштабування", case3_h:"Оля, 31 — 90 днів", case3_p:"Додала 2 акаунти, налаштувала графік і ризик-менеджмент.",
    m_deals:"угод", m_spread:"сер. спред", m_profit:"прибуток",
    reviews_h2:"Відгуки учнів", reviews_p:"Залиште відгук — він з’явиться на сторінці та відправиться менеджеру в Telegram.",
    f_name:"Ім’я", f_rating:"Оцінка", f_text:"Ваш відгук", f_files:"Фото/відео (до 5 файлів)",
    f_hint:"Фото зберігаються в історії відгуку. Відео до ~5 МБ зберігаються, більші — видимі до перезавантаження. Через посилання в Telegram файли не прикріплюються — надішліть їх менеджеру окремо.",
    send_review:"Надіслати відгук", see_reviews:"Переглянути відгуки", consent:"Натискаючи «Надіслати», ви погоджуєтесь із публікацією вашого відгуку на цій сторінці.",
    contact_h2:"Готовий почати?", contact_p:"Постав запитання або запроси програму на найближчий потік. Менеджер відповість у Telegram", contact_cta:"Перейти в Telegram",
    faq_1_q:"Чи потрібен досвід?", faq_1_a:"Ні, курс розрахований на старт з нуля, але буде корисний і чинним трейдерам.",
    faq_2_q:"Скільки триває навчання?", faq_2_a:"В середньому 3–6 тижнів — залежно від темпу та навантаження.",
    faq_3_q:"Які біржі?", faq_3_a:"Працюємо з великими міжнародними біржами, акцент — безпека та регламенти."
  }
};

// ====== Базовые эффекты ======
document.getElementById('year').textContent = new Date().getFullYear();
document.querySelectorAll('.btn').forEach(btn=>{
  btn.addEventListener('mousemove', e=>{
    const r = btn.getBoundingClientRect();
    btn.style.setProperty('--mx', (e.clientX - r.left) + 'px');
    btn.style.setProperty('--my', (e.clientY - r.top) + 'px');
  });
});
const io = new IntersectionObserver((entries)=>{
  entries.forEach(entry=>{ if(entry.isIntersecting){ entry.target.classList.add('on'); io.unobserve(entry.target); }});
}, {threshold:.15});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));

// counters
const counters = document.querySelectorAll('.counter');
const ioc = new IntersectionObserver((entries)=>{
  entries.forEach(entry=>{
    if(!entry.isIntersecting) return;
    const el = entry.target; const to = parseFloat(el.dataset.to); const dec = parseInt(el.dataset.dec||'0',10);
    let start = null; const from = 0; const dur = 1400;
    function step(ts){ if(!start) start = ts; const p = Math.min((ts - start)/dur,1);
      const v = from + (to - from) * (1 - Math.pow(1-p, 3));
      el.textContent = dec ? v.toFixed(dec) : Math.floor(v).toString();
      if(p<1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step); ioc.unobserve(el);
  });
}, {threshold:.6});
counters.forEach(c=>ioc.observe(c));

// active nav highlight
const sections = ['about','stats','how','why','cases','reviews','contact'];
const map = new Map(); sections.forEach(id=>map.set(id, document.getElementById(id)));
const links = [...document.querySelectorAll('.navlinks a')];
function highlight(){ let active=null; const y=window.scrollY+120;
  map.forEach((el,id)=>{ if(el){ const top=el.getBoundingClientRect().top+window.scrollY; if(top<=y) active=id; }});
  links.forEach(a=>a.classList.toggle('active', a.getAttribute('href')==='#'+active));
} window.addEventListener('scroll', highlight, {passive:true}); highlight();

// ====== i18n застосування ======
const LANG_KEY='p2p_lang';
const langSelect=document.getElementById('langSelect');
langSelect.value = localStorage.getItem(LANG_KEY) || 'ru';
applyLang(langSelect.value);
langSelect.addEventListener('change', e=>{
  const val=e.target.value; localStorage.setItem(LANG_KEY,val); applyLang(val);
});
function applyLang(code){
  const dict = I18N[code] || I18N.ru;
  document.documentElement.setAttribute('lang', code==='uk'?'uk':'ru');
  document.documentElement.setAttribute('data-lang', code);
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key=el.getAttribute('data-i18n');
    if(dict[key]) el.textContent = dict[key];
  });
  document.title = dict.title || document.title;
}

// ====== Отзывы: демо + localStorage + медиа ======
const TG_LINK = "https://t.me/your_manager"; // TODO: замени на свой
const REV_KEY = 'p2p_reviews_v2';
const MAX_FILES = 5;
const MAX_VIDEO_PERSIST = 5 * 1024 * 1024; // ~5MB
const MAX_IMG_SIDE = 1280; // ресайз фоток

const demoReviews = [
  {name:'Алексей', stars:5, text:'Понравилась структура и быстрые ответы в чате. Разобрался с лимитами за 2 дня.', images:[], videos:[]},
  {name:'Вика', stars:5, text:'Отчётность и чек-листы — огонь. Сразу видно, где проседаю и что править.', images:[], videos:[]},
  {name:'Денис', stars:4, text:'Сложно было с верификацией на одной бирже, помогли с апелляцией — доволен.', images:[], videos:[]},
];

const preview = document.getElementById('preview');
const filesInput = document.getElementById('rfiles');
let sessionVideos = []; // object URLs for large videos (non-persistent)

filesInput.addEventListener('change', async (e)=>{
  preview.innerHTML = '';
  sessionVideos = [];
  const files = [...e.target.files].slice(0, MAX_FILES);
  for(const f of files){
    if(f.type.startsWith('image/')){
      const url = await readImageAsResizedDataURL(f, MAX_IMG_SIDE);
      const img = document.createElement('img'); img.src = url; img.alt=f.name;
      preview.appendChild(img);
    }else if(f.type.startsWith('video/')){
      const v = document.createElement('video'); v.controls = true;
      const objUrl = URL.createObjectURL(f); v.src = objUrl; sessionVideos.push({name:f.name, size:f.size, objUrl});
      preview.appendChild(v);
    }
  }
});

function renderReviews(){
  const saved = JSON.parse(localStorage.getItem(REV_KEY) || '[]');
  const list = document.getElementById('reviews-list');
  list.innerHTML = '';
  [...demoReviews, ...saved].forEach(r=>list.appendChild(renderReview(r)));
}

function renderReview(r){
  const el = document.createElement('div');
  el.className = 'review reveal';
  const stars = '★'.repeat(r.stars) + '☆'.repeat(5-r.stars);
  el.innerHTML = `
    <div class="head">
      <div class="avatar" aria-hidden="true"></div>
      <div>
        <div class="name"></div>
        <div class="stars">${stars}</div>
      </div>
    </div>
    <div class="muted"></div>
    <div class="media"></div>
  `;
  el.querySelector('.name').textContent = r.name;
  el.querySelector('.muted').textContent = r.text;
  const media = el.querySelector('.media');
  (r.images||[]).forEach(src=>{
    const img = document.createElement('img'); img.src = src; img.alt="image"; media.appendChild(img);
  });
  (r.videos||[]).forEach(v=>{
    const vd = document.createElement('video'); vd.controls = true; vd.src = v.src; media.appendChild(vd);
  });
  io.observe(el);
  return el;
}

document.getElementById('reviewForm').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const name = document.getElementById('rname').value.trim();
  const stars = parseInt(document.getElementById('rstars').value, 10);
  const text = document.getElementById('rtext').value.trim();
  if(!name || !text) return;

  const files = [...filesInput.files].slice(0, MAX_FILES);
  const images = [];
  const videos = [];

  for(const f of files){
    if(f.type.startsWith('image/')){
      const url = await readImageAsResizedDataURL(f, MAX_IMG_SIDE);
      images.push(url);
    }else if(f.type.startsWith('video/')){
      if(f.size <= MAX_VIDEO_PERSIST){
        const dataURL = await fileToDataURL(f);
        videos.push({src:dataURL, persisted:true, name:f.name, size:f.size});
      }else{
        const objUrl = (sessionVideos.find(s=>s.name===f.name && s.size===f.size)?.objUrl) || URL.createObjectURL(f);
        videos.push({src:objUrl, persisted:false, name:f.name, size:f.size});
      }
    }
  }

  // Save (без больших видео)
  const persistableVideos = videos.filter(v=>v.persisted);
  const item = {name, stars, text, images, videos: persistableVideos};
  const saved = JSON.parse(localStorage.getItem(REV_KEY) || '[]'); saved.push(item);
  localStorage.setItem(REV_KEY, JSON.stringify(saved));

  // Render
  const displayItem = { ...item, videos: [...persistableVideos, ...videos.filter(v=>!v.persisted)] };
  const list = document.getElementById('reviews-list'); list.prepend(renderReview(displayItem));

  // Send to Telegram (text only)
  const msg = encodeURIComponent(`Новый отзыв с лендинга:\nИмя: ${name}\nОценка: ${'★'.repeat(stars)}\nТекст: ${text}\nМедиа: фото ${images.length}, видео ${videos.length}`);
  window.open(`https://t.me/your_manager?startapp=${msg}`, '_blank');

  // Cleanup
  e.target.reset(); document.getElementById('preview').innerHTML=''; sessionVideos=[];
});

async function fileToDataURL(file){
  return new Promise((resolve,reject)=>{
    const r = new FileReader(); r.onload=()=>resolve(r.result); r.onerror=reject; r.readAsDataURL(file);
  });
}
async function readImageAsResizedDataURL(file, maxSide=1280){
  const dataURL = await fileToDataURL(file);
  const img = new Image(); img.src = dataURL; await img.decode();
  const cvs = document.createElement('canvas'); let {width:w,height:h}=img; const ratio=w/h;
  if(Math.max(w,h) > maxSide){ if(w>=h){ w=maxSide; h=Math.round(w/ratio);} else { h=maxSide; w=Math.round(h*ratio);} }
  cvs.width=w; cvs.height=h; const ctx=cvs.getContext('2d'); ctx.drawImage(img,0,0,w,h);
  return cvs.toDataURL('image/jpeg', 0.86);
}

// Init
renderReviews();
